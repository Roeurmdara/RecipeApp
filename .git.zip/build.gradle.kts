buildscript {
    dependencies {
        classpath("com.google.gms:google-services:4.4.0")  // ADD THIS LINE
    }
}


plugins {
    id("com.android.application") version "8.13.1" apply false
}